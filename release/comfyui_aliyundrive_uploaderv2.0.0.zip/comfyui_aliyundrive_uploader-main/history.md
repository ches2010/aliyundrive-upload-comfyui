# 更新历史
## v1.0.0
1.通过输入`folder_id`和`refresh_token`实时上传图片到你的阿里云服务器。

## v1.1.0
1.增加新节点，只需将`folder_id`和`refresh_token`保存到`aliyundrive_config.json`，运行时可直接调用，无需在节点上输入。

2.新节点增加预览功能。
